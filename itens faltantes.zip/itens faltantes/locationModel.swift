//
//  locationModel.swift
//  The Umbrella
//
//  Created by Lestad on 2021-01-03.
//  Copyright © 2021 Lestad. All rights reserved.
//

import Foundation

class locationModel: NSObject {
    var name: String!
    var latitude: Double!
    var longitude: Double!
    var userID: String!
}
